sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.cpg.form.formmodule.controller.View1",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map